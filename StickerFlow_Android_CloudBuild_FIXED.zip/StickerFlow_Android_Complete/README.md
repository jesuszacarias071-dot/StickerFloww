# StickerFlow Android Complete

Proyecto Android con:
- target/compile SDK 36.
- Importación mediante selector Android.
- Recepción de imágenes/vídeos desde el menú Compartir.
- Editor WebView para crear stickers 512x512 en WebP.
- Texto.
- Guardado de stickers en almacenamiento privado de la app.
- ContentProvider con los endpoints de sticker pack requeridos por la integración oficial de WhatsApp.
- Botón que lanza `com.whatsapp.intent.action.ENABLE_STICKER_PACK` para que el usuario confirme la incorporación.

FUENTES / INTEGRACIÓN:
La estructura del ContentProvider y el intent de incorporación siguen el ejemplo oficial de WhatsApp:
https://github.com/WhatsApp/stickers

PARA PUBLICAR:
1. Abrir en Android Studio actualizado.
2. Sync Project with Gradle Files.
3. Crear un keystore de firma.
4. Build > Generate Signed Bundle / APK > Android App Bundle.
5. Subir el `.aab` a Play Console.

IMPORTANTE:
- El icono `sticker_tray.png` incluido es un placeholder mínimo; antes de publicar debe sustituirse por un icono de bandeja real de 96x96 o el tamaño recomendado por la documentación de WhatsApp.
- La versión implementada genera stickers estáticos WebP. El modo animado está señalado en la UI pero todavía guarda un fotograma estático; no se presenta como sticker animado real.
- El nombre de la app deliberadamente es `StickerFlow`, no contiene “WhatsApp”, siguiendo la recomendación del repositorio oficial de stickers de WhatsApp.
