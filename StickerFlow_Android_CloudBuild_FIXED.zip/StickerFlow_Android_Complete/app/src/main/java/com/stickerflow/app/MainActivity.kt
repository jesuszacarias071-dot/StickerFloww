package com.stickerflow.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.*
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.webkit.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import android.util.Base64

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(v: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?): Boolean {
                fileCallback = cb
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type="*/*"; putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*","video/*"))
                    addCategory(Intent.CATEGORY_OPENABLE)
                }, 1001)
                return true
            }
        }
        web.addJavascriptInterface(Bridge(this), "StickerFlowAndroid")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
        handleShare(intent)
    }

    private var fileCallback: ValueCallback<Array<Uri>>? = null
    override fun onActivityResult(req:Int,res:Int,data:Intent?) {
        super.onActivityResult(req,res,data)
        if(req==1001){
            val uris=data?.data?.let{arrayOf(it)} ?: emptyArray()
            fileCallback?.onReceiveValue(if(res==Activity.RESULT_OK) uris else null);fileCallback=null
        }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handleShare(intent) }

    private fun handleShare(intent:Intent?) {
        if(intent?.action==Intent.ACTION_SEND){
            val uri=intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM) ?: return
            try{
                val bytes=contentResolver.openInputStream(uri)?.use{it.readBytes()} ?: return
                val mime=contentResolver.getType(uri) ?: "image/*"
                val data="data:$mime;base64,"+Base64.encodeToString(bytes,Base64.NO_WRAP)
                web.post { web.evaluateJavascript("window.receiveSharedFile(${org.json.JSONObject.quote(data)});",null) }
            }catch(_:Exception){}
        }
    }

    private class Bridge(private val a:Activity) {
        @JavascriptInterface fun saveSticker(name:String, dataUrl:String):Boolean {
            return try {
                val base=dataUrl.substringAfter(",")
                val bytes=Base64.decode(base,Base64.DEFAULT)
                val dir=File(a.filesDir,"sticker_packs/1").apply{mkdirs()}
                val safe=name.replace(Regex("[^A-Za-z0-9._-]"),"_")
                FileOutputStream(File(dir,safe)).use{it.write(bytes)}
                true
            }catch(_:Exception){false}
        }
        @JavascriptInterface fun addToWhatsApp():Boolean {
            return try {
                val i=Intent("com.whatsapp.intent.action.ENABLE_STICKER_PACK")
                i.putExtra("sticker_pack_id","1")
                i.putExtra("sticker_pack_authority","com.stickerflow.app.stickercontentprovider")
                i.putExtra("sticker_pack_name","Mis stickers")
                a.startActivityForResult(i,200);true
            }catch(e:Exception){
                Toast.makeText(a,"WhatsApp no está instalado o no admite esta acción.",Toast.LENGTH_LONG).show();false
            }
        }
        @JavascriptInterface fun toast(s:String){Toast.makeText(a,s,Toast.LENGTH_SHORT).show()}
    }
}
