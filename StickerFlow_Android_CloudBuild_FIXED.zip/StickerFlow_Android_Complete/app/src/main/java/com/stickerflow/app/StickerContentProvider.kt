package com.stickerflow.app

import android.content.*
import android.content.res.AssetFileDescriptor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import java.io.File

class StickerContentProvider : ContentProvider() {
    private val authority = "com.stickerflow.app.stickercontentprovider"
    private val packId = "1"
    private val packName = "Mis stickers"
    private val publisher = "StickerFlow"

    override fun onCreate(): Boolean = true

    override fun query(uri: Uri, projection: Array<String>?, selection: String?, selectionArgs: Array<String>?, sortOrder: String?): android.database.Cursor? {
        val path=uri.pathSegments
        val c=MatrixCursor(arrayOf(
            "sticker_pack_identifier","sticker_pack_name","sticker_pack_publisher",
            "sticker_pack_icon","android_play_store_link","ios_app_store_link",
            "publisher_email","publisher_website","privacy_policy_website",
            "license_agreement_website","image_data_version","avoid_cache",
            "animated_sticker_pack","sticker_file_name","sticker_emoji"
        ))
        if(path.size==1 && path[0]=="metadata"){
            c.addRow(arrayOf(packId,packName,publisher,"sticker_tray.png","","","","","","","1",0,0,"",""))
        } else if(path.size==2 && path[0]=="metadata"){
            c.addRow(arrayOf(packId,packName,publisher,"sticker_tray.png","","","","","","","1",0,0,"",""))
        } else if(path.size==2 && path[0]=="stickers"){
            files().forEach{f->c.addRow(arrayOf(packId,packName,publisher,"sticker_tray.png","","","","","","","1",0,0,f.name,"😀"))}
        }
        return c
    }

    override fun getType(uri:Uri):String = "image/webp"

    override fun openAssetFile(uri:Uri,mode:String):AssetFileDescriptor? {
        val p=uri.pathSegments
        if(p.size==3 && p[0]=="stickers_asset"){
            val file=File(context!!.filesDir,"sticker_packs/${p[1]}/${p[2]}")
            if(file.exists()) return AssetFileDescriptor(ParcelFileDescriptor.open(file,ParcelFileDescriptor.MODE_READ_ONLY),0,AssetFileDescriptor.UNKNOWN_LENGTH)
        }
        return null
    }

    override fun openFile(uri:Uri,mode:String):ParcelFileDescriptor? {
        val p=uri.pathSegments
        if(p.size==3 && p[0]=="stickers_asset"){
            val file=File(context!!.filesDir,"sticker_packs/${p[1]}/${p[2]}")
            if(file.exists()) return ParcelFileDescriptor.open(file,ParcelFileDescriptor.MODE_READ_ONLY)
        }
        throw java.io.FileNotFoundException()
    }

    private fun files():List<File> = File(context!!.filesDir,"sticker_packs/$packId").listFiles()?.filter{it.isFile} ?: emptyList()

    override fun insert(uri:Uri,v:ContentValues?):Uri?=null
    override fun delete(uri:Uri,s:String?,a:Array<String>?):Int=0
    override fun update(uri:Uri,v:ContentValues?,s:String?,a:Array<String>?):Int=0
}
