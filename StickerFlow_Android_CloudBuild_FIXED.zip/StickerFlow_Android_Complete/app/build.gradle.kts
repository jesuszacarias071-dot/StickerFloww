plugins {
    id("com.android.application")
    kotlin("android")
}
android {
    namespace = "com.stickerflow.app"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.stickerflow.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0"
        buildConfigField("String", "CONTENT_PROVIDER_AUTHORITY", "\"com.stickerflow.app.stickercontentprovider\"")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures { buildConfig = true }
}
dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("com.google.android.material:material:1.13.0")
    implementation("androidx.activity:activity-ktx:1.11.0")
}
