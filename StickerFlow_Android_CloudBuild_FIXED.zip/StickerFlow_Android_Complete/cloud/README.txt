CLOUD BUILD

1. Upload StickerFlow_Android_CloudBuild.zip to the GitHub repository.
2. Create .github/workflows/build.yml using cloud/build.yml from this package.
3. Open Actions > Build StickerFlow APK > Run workflow.
4. Download the StickerFlow-APK artifact.

The workflow uses GitHub Actions, JDK 17, Android SDK 36 and Gradle 8.13.
